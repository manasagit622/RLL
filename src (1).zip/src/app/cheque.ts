export class Cheque {
    constructor(public cheque:string,
        public accountno:number){}
}
