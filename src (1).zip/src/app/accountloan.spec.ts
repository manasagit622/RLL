import { Accountloan } from './accountloan';

describe('Accountloan', () => {
  it('should create an instance', () => {
    expect(new Accountloan()).toBeTruthy();
  });
});
