export class Accountloan {
    constructor( public loan:number,
                public accountno:number
    ){}
}
