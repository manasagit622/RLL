export class Userregister {
    constructor(public name:string,
        public email:string,
        public password:string,
        public phno:number,
        public address:string,
        public panno: number,
        public date: Date,
        public transactionpassword: string){}
}
