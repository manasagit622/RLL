export class Account {
    constructor( public accountno:number,
                //public userid:User,
                //public loanid
                //public transactionid
                public balance:number,
                public accounttype:String,
       
        ){}
}
